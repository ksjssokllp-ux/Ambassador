package com.example.ambassador

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.content.res.ColorStateList
import android.os.Handler
import android.os.Looper
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var fxView: FxView
    private lateinit var status: TextView
    private var blackMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(4, 8, 18)) }
        fxView = FxView(this)
        root.addView(fxView, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 12)
        }
        val title = TextView(this).apply {
            text = "AMBASSADOR"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setShadowLayer(8f, 0f, 0f, Color.CYAN)
        }
        val subtitle = TextView(this).apply {
            text = "GLITCH EFFECT LAB • SIMULATOR ONLY"
            textSize = 11f
            setTextColor(Color.rgb(110, 220, 240))
        }
        status = TextView(this).apply {
            text = "Status: Normal"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 0)
        }
        header.addView(title)
        header.addView(subtitle)
        header.addView(status)
        root.addView(header, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 18)
            setBackgroundColor(Color.argb(210, 7, 14, 27))
        }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun makeButton(label: String, color: Int, action: () -> Unit): Button {
            return Button(this).apply {
                text = label
                textSize = 12f
                isAllCaps = false
                setTextColor(Color.WHITE)
                backgroundTintList = ColorStateList.valueOf(color)
                setOnClickListener { action() }
            }
        }
        fun addWeighted(row: LinearLayout, button: Button) {
            row.addView(button, LinearLayout.LayoutParams(0, -2, 1f))
        }
        addWeighted(row1, makeButton("Freeze", Color.rgb(45, 88, 130)) {
            fxView.setEffect(Effect.FREEZE); setStatus("Freeze: animasi berhenti")
        })
        addWeighted(row1, makeButton("Lag / Stutter", Color.rgb(112, 78, 145)) {
            fxView.setEffect(Effect.STUTTER); setStatus("Lag: simulasi animasi tersendat")
        })
        addWeighted(row2, makeButton("Delay", Color.rgb(37, 113, 119)) {
            fxView.setEffect(Effect.DELAY); setStatus("Delay: animasi bergerak dengan jeda")
        })
        addWeighted(row2, makeButton("Black Screen", Color.rgb(65, 65, 75)) {
            blackMode = true
            fxView.setEffect(Effect.BLACK)
            setStatus("Black Screen demo — tekan Restore untuk kembali")
        })
        buttons.addView(row1)
        buttons.addView(row2)
        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addWeighted(row3, makeButton("Restore / Normal", Color.rgb(28, 126, 82)) {
            blackMode = false
            fxView.setEffect(Effect.NORMAL)
            setStatus("Status: Normal")
        })
        addWeighted(row3, makeButton("STOP / EXIT", Color.rgb(185, 38, 66)) { finish() })
        buttons.addView(row3)
        root.addView(buttons, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun setStatus(message: String) { status.text = "Status: $message" }

    override fun onPause() {
        super.onPause()
        if (::fxView.isInitialized) fxView.setActive(false)
    }

    override fun onResume() {
        super.onResume()
        if (::fxView.isInitialized) fxView.setActive(true)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { finish() }
}

private enum class Effect { NORMAL, FREEZE, STUTTER, DELAY, BLACK }

private class FxView(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private var effect = Effect.NORMAL
    private var active = true
    private var frame = 0
    private var time = 0f
    private var widthF = 1f
    private var heightF = 1f
    private val random = Random(731)
    private val drops = mutableListOf<Drop>()
    private val chars = "01アイウエオカキクケコサシスセソタチツテト"
    private data class Drop(var x: Float, var y: Float, var speed: Float, var size: Float)

    private val ticker = object : Runnable {
        override fun run() {
            if (active) {
                if (effect != Effect.FREEZE && effect != Effect.BLACK) {
                    if (effect != Effect.STUTTER || frame % 4 != 0) time += 0.035f
                    frame++
                    invalidate()
                }
                handler.postDelayed(this, if (effect == Effect.DELAY) 160L else 32L)
            }
        }
    }

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    fun setEffect(next: Effect) {
        effect = next
        if (next == Effect.NORMAL || next == Effect.DELAY || next == Effect.STUTTER) {
            active = true
            handler.removeCallbacks(ticker)
            handler.post(ticker)
        } else {
            invalidate()
        }
    }

    fun setActive(value: Boolean) {
        active = value
        handler.removeCallbacks(ticker)
        if (active && effect != Effect.FREEZE && effect != Effect.BLACK) handler.post(ticker)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (active && effect != Effect.FREEZE && effect != Effect.BLACK) handler.post(ticker)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        widthF = w.toFloat().coerceAtLeast(1f)
        heightF = h.toFloat().coerceAtLeast(1f)
        drops.clear()
        val columns = (widthF / 22f).toInt().coerceAtLeast(1)
        repeat(columns) {
            drops.add(Drop(it * 22f, random.nextFloat() * heightF,
                2.5f + random.nextFloat() * 7f, 12f + random.nextFloat() * 8f))
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (effect == Effect.BLACK) {
            canvas.drawColor(Color.BLACK)
            return
        }
        canvas.drawColor(Color.rgb(4, 8, 18))
        if (effect == Effect.FREEZE) {
            paint.color = Color.WHITE
            paint.textSize = 18f
            paint.typeface = Typeface.DEFAULT_BOLD
            canvas.drawText("FROZEN DEMO", 30f, heightF * 0.55f, paint)
            paint.textSize = 12f
            canvas.drawText("Animasi dijeda. Pilih Restore / Normal untuk lanjut.", 30f, heightF * 0.55f + 26f, paint)
            return
        }

        val shakeX = if (effect == Effect.STUTTER) sin(time * 2.4f) * 5f else 0f
        val shakeY = if (effect == Effect.STUTTER) sin(time * 3.1f) * 4f else 0f
        canvas.save()
        canvas.translate(shakeX, shakeY)
        paint.typeface = Typeface.MONOSPACE
        for (drop in drops) {
            paint.textSize = drop.size
            paint.color = Color.argb(175, 35, 255, 135)
            canvas.drawText(chars[random.nextInt(chars.length)].toString(), drop.x, drop.y, paint)
            drop.y += if (effect == Effect.DELAY) drop.speed * 0.35f else drop.speed
            if (drop.y > heightF + 30f) drop.y = -random.nextFloat() * 300f
        }
        if (effect == Effect.STUTTER && frame % 2 == 0) {
            for (i in 0 until 6) {
                val y = random.nextFloat() * heightF
                val left = random.nextFloat() * widthF * 0.7f
                val barWidth = 40f + random.nextFloat() * widthF * 0.25f
                paint.color = Color.argb(105, 255, 30, 90)
                canvas.drawRect(left - 3f, y, left + barWidth, y + 5f, paint)
                paint.color = Color.argb(105, 0, 220, 255)
                canvas.drawRect(left + 4f, y + 3f, left + barWidth + 8f, y + 8f, paint)
            }
        }
        canvas.restore()
    }
}
