# Ambassador — Android Visual Glitch Simulator

Aplikasi demo Android yang menampilkan efek visual di dalam aplikasinya saja. Efek tidak membekukan sistem Android, tidak mengganggu aplikasi lain, tidak mengakses nomor telepon, dan tidak memantau perangkat dari jarak jauh.

## Fitur
- Freeze: menjeda animasi demo.
- Lag / Stutter: efek visual tersendat dengan garis glitch.
- Delay: animasi bergerak lebih lambat.
- Black Screen: area visual aplikasi menjadi hitam.
- Restore / Normal: mengembalikan tampilan.
- STOP / EXIT dan tombol Back untuk keluar.

## Cara build APK
Persyaratan: Android Studio, JDK yang didukung Android Studio, dan koneksi internet untuk mengunduh Gradle/Android Gradle Plugin.

1. Ekstrak ZIP ini.
2. Buka Android Studio, pilih **Open**, lalu pilih folder `Ambassador`.
3. Tunggu proses Gradle Sync selesai. Jika diminta, instal Android SDK Platform 35.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Setelah selesai, pilih **locate** pada notifikasi build. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
6. Pindahkan APK ke HP milik sendiri dan instal. Android mungkin meminta izin untuk memasang aplikasi dari sumber tersebut.

## Build lewat terminal
Di folder proyek, jika Gradle tersedia:
```bash
gradle assembleDebug
```
APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
Proyek ini menyediakan source code. APK biner belum disertakan karena proses build memerlukan Android SDK/Gradle di komputer.
